package nl.tudelft.jpacman.level;

import nl.tudelft.jpacman.npc.Ghost;
import nl.tudelft.jpacman.points.PointCalculator;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;

/**
 * Class to verify the collide method from the DefaultPlayerInteractionMap class.
 */
public class DefaultPlayerInteractionMapTest extends CollisionMapTest {

    /**
     * 初始化一个计分器，一个玩家，一个小球和一个幽灵以及一个DefaultPlayerInteractionMap对象用于测试
     * 使用Mockito.mock(classToMock)创建模拟对象
     */
    @BeforeEach
    @Override
    void init() {
        this.setPointCalculator(Mockito.mock(PointCalculator.class));
        this.setPlayer(Mockito.mock(Player.class));
        this.setPellet(Mockito.mock(Pellet.class));
        this.setGhost(Mockito.mock(Ghost.class));
        //通过setPlayerCollisions()方法传入DefaultPlayerInteractionMap一个对象（该类为接口CollisionMap的实现类）
        this.setPlayerCollisions(new DefaultPlayerInteractionMap(this.getPointCalculator()));
    }
}
