package nl.tudelft.jpacman.board;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * 方向测试。
 */
public class DirectionTest {
    /**
     * Do we get the correct delta when moving north?
     */
    @Test
    @DisplayName("NORTH")
    void testNorth() {
        Direction north = Direction.valueOf("NORTH");
        assertThat(north.getDeltaY()).isEqualTo(-1);
        assertThat(north.getDeltaX()).isEqualTo(0);
    }

    /**
     * 测试方向南。
     */
    @Test
    @DisplayName("SOUTH")
    void testSouth() {
        Direction south = Direction.valueOf("SOUTH");
        assertThat(south.getDeltaY()).isEqualTo(1);
        assertThat(south.getDeltaX()).isEqualTo(0);
    }

    /**
     * 测试方向西。
     */
    @Test
    @DisplayName("WEST")
    void testWest() {
        Direction west = Direction.valueOf("WEST");
        assertThat(west.getDeltaX()).isEqualTo(-1);
        assertThat(west.getDeltaY()).isEqualTo(0);
    }

    /**
     * 测试方向东。
     */
    @Test
    @DisplayName("EAST")
    void testEast() {
        Direction east = Direction.valueOf("EAST");
        assertThat(east.getDeltaX()).isEqualTo(1);
        assertThat(east.getDeltaY()).isEqualTo(0);
    }
}
