package nl.tudelft.jpacman.board;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * 测试一个单元是否占用棋盘中的一个方格。
 *
 */
class OccupantTest {

    /**
     * 创建被测试单元对象。
     */
    private Unit unit;      //定义Unit对象

    /**
     * 重置被测试单元对象。
     */
    @BeforeEach     //在每个测试方法之前执行
    void setUp() {
        unit = new BasicUnit();
    }

    /**
     * 测试一个单元开始没有占用方格。
     */
    @Test
    void noStartSquare() {
        assertThat(unit).isNotNull();

        assertThat(unit.hasSquare()).isFalse();         //判断是否被占据
    }

    /**
     * 测试当单元占据一个方格后该方格是否包含该单元对象。
     */
    @Test
    void testOccupy() {
        assertThat(unit).isNotNull();
        Square square = new BasicSquare();
        unit.occupy(square);                //unit占据square
        assertThat(unit.getSquare()).isEqualTo(square);     //判断unit是否拥有一个目标square
        assertThat(square.getOccupants()).contains(unit);       //判断square是否包含（contains）了一个unit
    }

    /**
     * 测试重复两次占据方格。
     */
    @Test
    void testReoccupy() {
        assertThat(unit).isNotNull();
        Square square = new BasicSquare();
        unit.occupy(square);        //unit重复占用两次
        unit.occupy(square);
        assertThat(unit.getSquare()).isEqualTo(square);     //判断unit是否拥有一个目标square
        assertThat(square.getOccupants()).contains(unit);   //判断square是否包含(contains)了一个unit

    }
}
