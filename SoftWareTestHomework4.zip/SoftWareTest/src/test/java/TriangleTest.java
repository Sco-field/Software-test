
import cn.edu.ctgu.junittest.Triangle;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.assertEquals;
public class TriangleTest {
    @Test
    @DisplayName("输入错误")
    public void parameters_error_test() {
        Triangle triangle = new Triangle();
        String type1 = triangle.classify(0, 4, 5);
        assertEquals("输入错误", type1);
        String type2=triangle.classify(2,-2,4);
        assertEquals("输入错误", type2);
        String type3=triangle.classify(2,2,-1);
        assertEquals("输入错误", type3);
        String type4=triangle.classify(101,2,2);
        assertEquals("输入错误", type4);
        String type5=triangle.classify(1,101,2);
        assertEquals("输入错误", type5);
        String type6=triangle.classify(1,2,101);
        assertEquals("输入错误", type6);
    }
    @Test
    @DisplayName("不等边三角形")
    public void scalene_test() {
        Triangle triangle = new Triangle();
        String type = triangle.classify(3, 4, 6);
        assertEquals("不等边三角形", type);
    }
    @Test
    @DisplayName("等边三角形")
    public void Equilateral_test(){
        Triangle triangle = new Triangle();
        String type= triangle.classify(3,3,3);
        assertEquals("等边三角形",type);
    }
    @Test
    @DisplayName("等腰三角形")
    public void Isosceles_test(){
        Triangle triangle = new Triangle();
        String type1= triangle.classify(3,3,4);
        assertEquals("等腰三角形",type1);
        String type2= triangle.classify(3,5,3);
        assertEquals("等腰三角形",type2);
        String type3= triangle.classify(1,3,3);
        assertEquals("等腰三角形",type3);
    }
    @Test
    @DisplayName("非三角形")
    public void NotTriangle_test(){
        Triangle triangle = new Triangle();
        String type1= triangle.classify(1,2,3);
        assertEquals("非三角形",type1);
        String type2= triangle.classify(2,5,2);
        assertEquals("非三角形",type2);
        String type3= triangle.classify(6,2,2);
        assertEquals("非三角形",type3);
    }

}
