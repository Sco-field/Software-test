import cn.edu.ctgu.junittest.CalculateTimeAndMoney;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalculateTimeAndMoneyTest {
    @DisplayName("等价划分测试")
    @ParameterizedTest
    @CsvSource(value={
            "20210226140000,20210226140010,0.05,false,false",
            "20210329020000,20210329030020,5.1",
            "20211025025934,20211025020022,0.0",
            "20211025015922,20211025020020,0.05",
            "20210226140000,20210226141810,0.95",
            "20210329015900,20210329031610,6.8",
            "20211025025800,20211025021610,0.0",
            "20211025015800,20211025021610,0.95",
            "20210226140000,20210226153030,8.1",
            "20210329015900,20210329031610,6.8",
            "20211025015800,20211025023610,2.9",
            "20211025023610,20211025022610,0.0",
    })
    void sameTest(String starttime,String endtime,double expected){
        CalculateTimeAndMoney calculateTimeAndMoney=new CalculateTimeAndMoney(starttime,endtime);
        assertEquals(expected,calculateTimeAndMoney.getTelCost());
    }
    @DisplayName("决策表测试")
    @ParameterizedTest
    @CsvSource(value={
            "20220101000000,20220101001000,0.5,false,false",
            "20220320020000,20220320031000,6.0,false,true",
            "20221106025000,20221106020000,0.5,true,true",
            "20220101000000,20220101003000,2.0,false,false",
            "20221106020000,20221106020000,5.0,true,true",
    })
    void DecisionTable(String starttime,String endtime,double expected,boolean BeginTimeIsSummertime,boolean EndTimeIsSummertime){
        CalculateTimeAndMoney calculateTimeAndMoney=new CalculateTimeAndMoney(starttime,endtime);
        assertEquals(expected,calculateTimeAndMoney.getTelCost());
        assertEquals(BeginTimeIsSummertime,calculateTimeAndMoney.isSummerTime());
        assertEquals(EndTimeIsSummertime,calculateTimeAndMoney.isSummerTime());
    }


}