package cn.edu.ctgu.junittest;

public class main {
    public static void main(String[] args) {
        CalculateTimeAndMoney calculateTimeAndMoney=new CalculateTimeAndMoney("20220226140000","20220226140010");
        System.out.println(calculateTimeAndMoney.getTelCost());
    }
}
