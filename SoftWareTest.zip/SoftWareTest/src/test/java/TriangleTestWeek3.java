import cn.edu.ctgu.junitTest.Triangle;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TriangleTestWeek3 {
    @ParameterizedTest
    @DisplayName("一般边界值测试")
    @CsvSource(value = {
            "50,50,50,等边三角形",
            "1,50,50,等腰三角形",
            "2,50,50,等腰三角形",
            "99,50,50,等腰三角形",
            "100,50,50,非三角形",
            "50,1,50,等腰三角形",
            "50,2,50,等腰三角形",
            "50,99,50,等腰三角形",
            "50,100,50,非三角形",
            "50,50,1,等腰三角形",
            "50,50,2,等腰三角形",
            "50,50,99,等腰三角形",
            "50,50,100,非三角形",
    })
    public void General_boundaryTest (int a,int b,int c,String expected) {
        Triangle triangle = new Triangle();
        assertEquals(expected,triangle.classify(a,b,c)) ;
    }

    @ParameterizedTest
    @DisplayName("健壮性边界值测试")
    @CsvSource(value = {
            "50,50,50,等边三角形",
            "0,50,50,输入错误",
            "1,50,50,等腰三角形",
            "2,50,50,等腰三角形",
            "99,50,50,等腰三角形",
            "100,50,50,非三角形",
            "101,50,50,输入错误",
            "50,0,50,输入错误",
            "50,1,50,等腰三角形",
            "50,2,50,等腰三角形",
            "50,99,50,等腰三角形",
            "50,100,50,非三角形",
            "50,101,50,输入错误",
            "50,50,0,输入错误",
            "50,50,1,等腰三角形",
            "50,50,2,等腰三角形",
            "50,50,99,等腰三角形",
            "50,50,100,非三角形",
            "50,50,101,输入错误",
    })
    public void Robustness_boundaryTest (int a,int b,int c,String expected) {
        Triangle triangle = new Triangle();
        assertEquals(expected,triangle.classify(a,b,c)) ;
    }

    @ParameterizedTest
    @DisplayName("一般最坏边界值测试")
    @CsvFileSource(resources = "/General_worst.csv")
    public void GeneralWorst_boundaryTest (int a,int b,int c,String expected) {
        Triangle triangle = new Triangle();
        assertEquals(expected,triangle.classify(a,b,c)) ;
        System.out.println(expected);
    }
//
    @ParameterizedTest
    @DisplayName("健壮最坏边界值测试")
    @CsvFileSource(resources = "/Robustness_worst.csv")
    public void RobustnessWorst_boundaryTest (int a,int b,int c,String expected) {
        Triangle triangle = new Triangle();
        assertEquals(expected,triangle.classify(a,b,c)) ;
    }


}
