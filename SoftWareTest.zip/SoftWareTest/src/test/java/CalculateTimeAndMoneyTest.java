import cn.edu.ctgu.junitTest.CalculateTimeAndMoney;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalculateTimeAndMoneyTest {
    @DisplayName("等价划分测试")
    @ParameterizedTest
    @CsvSource(value={
            "20210226140000,20210226140010,0.05",
            "20210329020000,20210329030020,5.1",
            "20211025025934,20211025020022,0.0",
            "20211025015922,20211025020020,0.05",
            "20210226140000,20210226141810,0.95",
            "20210329015900,20210329031610,6.8",
            "20211025025800,20211025021610,0.0",
            "20211025015800,20211025021610,0.95",
            "20210226140000,20210226153030,8.1",
            "20210329015900,20210329031610,6.8",
            "20211025015800,20211025023610,2.9",
            "20211025023610,20211025022610,0.0",
    })
    void sameTest(String starttime,String endtime,double expected){
        CalculateTimeAndMoney calculateTimeAndMoney=new CalculateTimeAndMoney(starttime,endtime);
        assertEquals(expected,calculateTimeAndMoney.getTelCost());
    }

}