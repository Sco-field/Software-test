package cn.edu.ctgu.junitTest;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class CalculateTimeAndMoney {
    public String startTime, endTime;
    public long minutes;
    public Date startDate, endDate;

    public Date ParseStringtoDate(String str) {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = null;
        try {
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    public CalculateTimeAndMoney(String startTime, String endTime) {
        this.startDate = this.ParseStringtoDate(startTime);
        this.endDate = this.ParseStringtoDate(endTime);
    }

    public String DatetoString(Date date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss E");
        String stringdate = simpleDateFormat.format(date);
        return stringdate;
    }

    public long Calculate() {
        long time;
        Calendar startcalendar = Calendar.getInstance();
        startcalendar.setTime(startDate);
        Calendar endcalendar = Calendar.getInstance();
        endcalendar.setTime(endDate);
        time = endcalendar.getTime().getTime() - startcalendar.getTime().getTime();
        if (time < 0) {
            minutes = ((endcalendar.getTime().getTime() - startcalendar.getTime().getTime()) / 1000) / 60;//得到通话时长
        } else {
            minutes = (time / 1000 + 59) / 60;
        }
        if ((startcalendar.get(Calendar.MONTH) == Calendar.MARCH && startcalendar.get(Calendar.DATE) >= 29 && startcalendar.get(Calendar.DATE) <= 31 &&
                startcalendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) || ((startcalendar.get(Calendar.MONTH) == Calendar.APRIL) &&
                startcalendar.get(Calendar.DATE) >= 1 && startcalendar.get(Calendar.DATE) <= 4 && startcalendar.get((Calendar.DAY_OF_WEEK)) == Calendar.SUNDAY)) {
            if (startcalendar.get(Calendar.HOUR_OF_DAY) < 2 && endcalendar.get(Calendar.HOUR_OF_DAY) >= 3) {
                minutes = minutes - 60;
            } }else {
                if ((endcalendar.get(Calendar.MONTH) == 3 && endcalendar.get(Calendar.DATE) >= 29 && endcalendar.get(Calendar.DATE) <= 31 && endcalendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)
                        || ((endcalendar.get(Calendar.MONTH) == 4 && endcalendar.get(Calendar.DATE) >= 1 && endcalendar.get(Calendar.DATE) <= 4 && endcalendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY))) {
                    //判断结束时间是否在转换的日期
                    if (endcalendar.get(Calendar.HOUR_OF_DAY) > 3) {
                        minutes -= 60;
                    }
                }
            }
            if (startcalendar.get(Calendar.MONTH) == Calendar.NOVEMBER && startcalendar.get(Calendar.DATE) >= 1 && startcalendar.get(Calendar.DATE) <= 7 && startcalendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
                if (startcalendar.get(Calendar.HOUR_OF_DAY) == 2) {
                    minutes += 60;
                }
            } else {
                if (endcalendar.get(Calendar.MONTH) == Calendar.NOVEMBER && endcalendar.get(Calendar.DATE) >= 1 && endcalendar.get(Calendar.DATE) <= 7 && endcalendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
                    if (endcalendar.get(Calendar.HOUR_OF_DAY) == 2) {
                        minutes += 60;
                    }
                }
            }
        if (minutes > 1200 || minutes < 0) {
            return 0;
        } else {
            return minutes;
        }
    }
    public double getTelCost() {
        double telCost;
        long time = Calculate();
        //计算话费
        if(time <= 20){
            telCost = 0.05*time;
        }else{
            telCost = 1.00 + (time - 20)*0.1;
        }
        BigDecimal b = new BigDecimal(telCost);
        telCost = b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        return telCost;
    }
}