package com.ctgu.mimic;

public class LinkedListRemove {
    public LinkedList<String> list1=new LinkedList<String>();
    public LinkedList<String> list2=new LinkedList<String>();
    public LinkedList<String> list3=new LinkedList<String>();
    public LinkedList<String> list4=new LinkedList<String>();
    public LinkedListRemove(){
        list2.add("A");
        list2.add("B");
        list2.add("C");
        list3.add("A");
        list3.add("B");
        list3.add(null);
        list4.add(null);
        list4.add("A");
        list4.add("B");
    }

}
