package mimic;

import com.ctgu.mimic.LinkedListRemove;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LinkedListRemoveTest {
    @Test
    public void RemoveTest(){
        LinkedListRemove list=new LinkedListRemove();
        assertEquals(false,list.list1.remove((String)null));
        assertEquals(false,list.list2.remove((String)null));
        assertEquals(true,list.list3.remove((String)null));
        assertEquals(true,list.list4.remove((String)null));
        assertEquals(false,list.list1.remove((String)"A"));
        assertEquals(true,list.list2.remove((String)"A"));
        assertEquals(true,list.list2.remove((String)"C"));
        assertEquals(false,list.list2.remove((String)"E"));



    }

}